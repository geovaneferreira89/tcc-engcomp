You can download the latest version of NLOG at

http://nlog-project.org/